package com.bookstoreApi;


import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    // You can define custom query methods here if needed
    List<Book> findByGenre(String genre);

    List<Book> findAll();

    Optional<Book> findById(Long id);
}
