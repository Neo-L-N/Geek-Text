package com.bookstoreApi;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class BookController<ResponseEntity> {
    private final BookRepository bookRepository;
    private final ShoppingCart shoppingCart;

    public BookController(BookRepository bookRepository, ShoppingCart shoppingCart) {
        this.bookRepository = bookRepository;
        this.shoppingCart = shoppingCart;
    }

    @GetMapping
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        return optionalBook.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/add-to-cart/{id}")
    public ResponseEntity<?> addToCart(@PathVariable Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if (optionalBook.isPresent()) {
            Book book = optionalBook.get();
            shoppingCart.addBook(book);
            return ResponseEntity.ok("Book added to the cart");
        }
        return ResponseEntity.notFound().build();
    }


    @PostMapping("/remove-from-cart/{id}")
    public ResponseEntity<?> removeFromCart(@PathVariable Long id) {
        Optional<Book> optionalBook = bookRepository.findById(id);
        if (optionalBook.isPresent()) {
            Book book = optionalBook.get();
            shoppingCart.removeBook(book);
            return ResponseEntity.ok("Book removed from the cart");
        }
        return ResponseEntity.notFound().build();
    }