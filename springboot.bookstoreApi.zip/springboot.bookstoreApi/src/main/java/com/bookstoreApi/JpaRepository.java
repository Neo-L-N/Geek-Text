package com.bookstoreApi;

public interface JpaRepository<T, T1> {
}
